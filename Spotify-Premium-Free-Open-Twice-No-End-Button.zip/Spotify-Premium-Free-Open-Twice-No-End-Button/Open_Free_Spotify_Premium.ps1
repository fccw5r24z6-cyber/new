$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$htmlPath = Join-Path $root 'free_spotify_premium.html'
$counterPath = Join-Path $root 'open_count.txt'

try {
    if (-not (Test-Path -LiteralPath $htmlPath)) {
        throw "Cannot find free_spotify_premium.html. Keep all files in the extracted folder together."
    }

    # Count each manual launch. Closing the window never relaunches it.
    $count = 0
    if (Test-Path -LiteralPath $counterPath) {
        $rawCount = (Get-Content -LiteralPath $counterPath -Raw).Trim()
        $parsedCount = 0
        if ([int]::TryParse($rawCount, [ref]$parsedCount) -and $parsedCount -ge 0) {
            $count = $parsedCount
        }
    }
    $count++
    Set-Content -LiteralPath $counterPath -Value $count -NoNewline -Encoding ascii

    $fullPath = [System.IO.Path]::GetFullPath($htmlPath)
    $url = ([System.Uri]::new($fullPath)).AbsoluteUri + "?launch=$count"

    # Prefer Chrome when installed. Edge can implicitly sign a newly created
    # profile into the Windows account and show a sync-consent screen.
    $basePaths = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) | Where-Object { $_ }
    $candidates = @()
    foreach ($relativePath in @('Google\Chrome\Application\chrome.exe', 'Microsoft\Edge\Application\msedge.exe')) {
        foreach ($basePath in $basePaths) {
            $candidates += (Join-Path $basePath $relativePath)
        }
    }
    foreach ($commandName in @('chrome.exe', 'msedge.exe')) {
        $cmd = Get-Command $commandName -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source) { $candidates += $cmd.Source }
    }

    $browser = $null
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            $browser = $candidate
            break
        }
    }
    if (-not $browser) {
        throw "Microsoft Edge or Google Chrome was not found. Install or repair Edge/Chrome, then run this launcher again. The fallback browser was skipped because it cannot reliably guarantee fullscreen app mode."
    }

    # Use a fresh profile for each opening. This prevents Chromium from forwarding
    # the request to an already-running browser process that ignores fullscreen flags.
    $profilesRoot = Join-Path $root 'browser_profiles'
    New-Item -ItemType Directory -Path $profilesRoot -Force | Out-Null
    $profilePath = Join-Path $profilesRoot ("launch-{0}" -f $count)
    New-Item -ItemType Directory -Path $profilePath -Force | Out-Null

    # Quote paths. Each launch uses an isolated profile and app-style fullscreen.
    # For Edge, explicitly disable account sync and implicit sign-in so a fresh
    # profile does not trigger the "sync your browsing data" consent screen.
    $quotedProfile = '"' + $profilePath.Replace('"', '\"') + '"'
    $quotedUrl = '"' + $url.Replace('"', '\"') + '"'
    if ([System.IO.Path]::GetFileName($browser) -ieq 'msedge.exe') {
        $arguments = "--user-data-dir=$quotedProfile --app=$quotedUrl --start-fullscreen --autoplay-policy=no-user-gesture-required --no-first-run --no-default-browser-check --disable-sync --disable-features=msImplicitSignin,msEdgeFirstRunExperience"
    } else {
        $arguments = "--user-data-dir=$quotedProfile --app=$quotedUrl --start-fullscreen --autoplay-policy=no-user-gesture-required --no-first-run --no-default-browser-check --disable-sync"
    }
    Start-Process -FilePath $browser -ArgumentList $arguments -ErrorAction Stop
} catch {
    Write-Host "Could not open Spotify-Premium-Open-Twice." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host "Extract the ZIP first, then run Open_Free_Spotify_Premium.bat from the extracted folder."
    Read-Host 'Press Enter to close'
    exit 1
}
