@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Open_Free_Spotify_Premium.ps1"
if errorlevel 1 (
  echo.
  echo The launcher could not start. Please read the error above.
  pause
)
